package com.pradita.budi.moviecatalogue2.adapter;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.activity.DetailTvActivity;
import com.pradita.budi.moviecatalogue2.api.Constant;
import com.pradita.budi.moviecatalogue2.model.TvShow;

public class FavouriteTvAdapter extends RecyclerView.Adapter<FavouriteTvAdapter.ViewHolder> {

    private Cursor tvCursor;
    private Activity activity;

    public FavouriteTvAdapter(Activity activity) {
        this.activity = activity;
    }

    public void setListTv(Cursor tvCursor) {
        this.tvCursor = tvCursor;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_tv_item, parent, false);
        return new FavouriteTvAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final TvShow tvShow = getItem(position);
        holder.name_tv.setText(tvShow.getName());
        holder.overview_tv.setText(tvShow.getOverview());
        Glide.with(activity)
                .load(Constant.IMAGE_URL + tvShow.getPoster_path())
                .placeholder(R.drawable.load)
                .into(holder.ivPoster);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, DetailTvActivity.class);
                intent.putExtra("id", tvShow.getId());
                intent.putExtra("name", tvShow.getName());
                intent.putExtra("overview", tvShow.getOverview());
                intent.putExtra("poster_path", tvShow.getPoster_path());
                activity.startActivity(intent);
            }
        });
    }

    private TvShow getItem(int position){
        if (!tvCursor.moveToPosition(position)) {
            throw new IllegalStateException("Position invalid");
        }
        return new TvShow(tvCursor);
    }

    @Override
    public int getItemCount() {
        if (tvCursor == null) return 0;
        return tvCursor.getCount();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView name_tv, overview_tv;
        private ImageView ivPoster;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            name_tv = itemView.findViewById(R.id.title_detail_tv);
            overview_tv = itemView.findViewById(R.id.overview_detail_tv);
            ivPoster = itemView.findViewById(R.id.iv_poster_tv);
        }
    }
}
