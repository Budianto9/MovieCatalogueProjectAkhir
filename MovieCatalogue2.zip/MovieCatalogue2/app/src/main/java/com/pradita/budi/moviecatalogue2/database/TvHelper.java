package com.pradita.budi.moviecatalogue2.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pradita.budi.moviecatalogue2.model.TvShow;

import java.util.ArrayList;

import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.OVERVIEW_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.POSTER_PATH_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TABLE_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TITLE_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TVSHOW_ID;

public class TvHelper {
    private static String DATABASE_TABLE = TABLE_TVSHOW;
    private Context context;
    private DatabaseHelper databaseHelper;

    private SQLiteDatabase database;

    public TvHelper(Context context){
        this.context = context;
    }

    public TvHelper open() throws SQLException {
        databaseHelper = new DatabaseHelper(context);
        database = databaseHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        databaseHelper.close();
    }

    public ArrayList<TvShow> query() {
        ArrayList<TvShow> arrayList = new ArrayList<>();
        Cursor cursor = database.query(DATABASE_TABLE,
                null,
                null,
                null,
                null,
                null, TVSHOW_ID + " DESC",
                null);
        cursor.moveToFirst();
        TvShow tvShowList;
        if (cursor.getCount() > 0){
            do {
                tvShowList = new TvShow();
                tvShowList.setId(cursor.getInt(cursor.getColumnIndexOrThrow(TVSHOW_ID)));
                tvShowList.setName(cursor.getString(cursor.getColumnIndexOrThrow(TITLE_TVSHOW)));
                tvShowList.setOverview(cursor.getString(cursor.getColumnIndexOrThrow(OVERVIEW_TVSHOW)));
                tvShowList.setPoster_path(cursor.getString(cursor.getColumnIndexOrThrow(POSTER_PATH_TVSHOW)));
                cursor.moveToNext();
            } while (!cursor.isAfterLast());
        }
        cursor.close();
        return arrayList;
    }


    public boolean getTvShowbyId(String id) {
        boolean result = false;
        Cursor cursor = database.query(DATABASE_TABLE,
                null,
                TVSHOW_ID + " = '"+id+"'",
                null,
                null,
                null,
                TVSHOW_ID + " ASC",
                null);
        cursor.moveToFirst();
        ArrayList<TvShow> tvShows = new ArrayList<>();
        TvShow tvShow;
        if (cursor.getCount() > 0) {
            result = true;
        }
        cursor.close();
        return result;
    }

    public Cursor queryByIdProvider(String id) {
        return database.query(DATABASE_TABLE, null
                , TVSHOW_ID + "=?"
                , new String[]{id}
                , null
                , null
                , null
                , null);
    }

    public Cursor queryProvider() {
        return database.query(DATABASE_TABLE
                , null
                , null
                , null
                , null
                , null
                , TVSHOW_ID + " DESC");
    }

    public long insertProvider(ContentValues values) {
        return database.insert(DATABASE_TABLE, null, values);
    }


    public int updateProvider(String id,ContentValues values){
        return database.update(DATABASE_TABLE,values,TVSHOW_ID +" = ?",new String[]{id} );
    }

    public int deleteProvider(String id){
        database.delete(DATABASE_TABLE, TVSHOW_ID + " = ?", new String[]{id});
        return 0;
    }
}
