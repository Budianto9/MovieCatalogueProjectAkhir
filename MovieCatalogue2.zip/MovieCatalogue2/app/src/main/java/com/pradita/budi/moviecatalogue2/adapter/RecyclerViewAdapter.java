package com.pradita.budi.moviecatalogue2.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pradita.budi.moviecatalogue2.api.Constant;
import com.pradita.budi.moviecatalogue2.activity.DetailActivity;
import com.pradita.budi.moviecatalogue2.model.Movie;
import com.pradita.budi.moviecatalogue2.R;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter
        .MyViewHolder> {

    public Context context;
    private ArrayList<Movie> movies;



    public RecyclerViewAdapter(Context context, ArrayList<Movie> movies) {
        this.context = context;
        this.movies = movies;
    }


    public void refill(ArrayList<Movie> movies) {
        this.movies = new ArrayList<>();
        this.movies.addAll(movies);
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return  new MyViewHolder(LayoutInflater.from(context).inflate(R.layout.list_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final Movie movie = movies.get(position);
        holder.getAdapterPosition();
        holder.title.setText(movies.get(position).getTitle());
        holder.overview.setText(movies.get(position).getOverview());
        holder.realease_date.setText(movies.get(position).getRelease_date());
        Glide.with(context)
                .load(Constant.IMAGE_URL+movies.get(position).getPoster_path())
                .placeholder(R.drawable.load)
                .into(holder.img);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("id", movie.getId());
                intent.putExtra("title", movie.getTitle());
                intent.putExtra("overview", movie.getOverview());
                intent.putExtra("release_date", movie.getRelease_date());
                intent.putExtra("poster_path", movie.getPoster_path());
                context.startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        if (movies == null){
            return 0;
        }
        return movies.size();
    }

    public void setMoviesList(List<Movie> list){
        movies.addAll(list);
    }



    static class MyViewHolder extends RecyclerView.ViewHolder {

        private TextView title, overview, realease_date;
        private ImageView img;

        MyViewHolder(View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.title_detail_cv);
            overview = itemView.findViewById(R.id.overview_detail_cv);
            realease_date = itemView.findViewById(R.id.release_date_detail_cv);
            img = itemView.findViewById(R.id.iv_poster_cv);
        }
    }



}
