package com.pradita.budi.moviecatalogue2.model;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.MOVIE_ID;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.OVERVIEW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.POSTER_PATH;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.RELEASE_DATE;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.TITLE_MOVIE;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.getColumnInt;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.getColumnString;

public class Movie implements Parcelable {
    private int id;
    private String title;
    private String overview;
    private String release_date;
    private String poster_path;

    public Movie(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public String getPoster_path() {
        return poster_path;
    }

    public void setPoster_path(String poster_path) {
        this.poster_path = poster_path;
    }

    protected Movie(Parcel in) {
        id = in.readInt();
        title = in.readString();
        overview = in.readString();
        release_date = in.readString();
        poster_path = in.readString();
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    public Movie(Cursor cursor){
        this.id = getColumnInt(cursor, MOVIE_ID);
        this.title = getColumnString(cursor, TITLE_MOVIE);
        this.overview = getColumnString(cursor, OVERVIEW);
        this.release_date = getColumnString(cursor, RELEASE_DATE);
        this.poster_path = getColumnString(cursor, POSTER_PATH);
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(overview);
        dest.writeString(release_date);
        dest.writeString(poster_path);
    }
}
