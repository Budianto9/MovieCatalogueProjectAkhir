package com.pradita.budi.moviecatalogue2.activity;

import android.app.SearchManager;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.Toast;

import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.adapter.RecyclerViewAdapter;
import com.pradita.budi.moviecatalogue2.adapter.TvShowAdapter;
import com.pradita.budi.moviecatalogue2.api.Constant;
import com.pradita.budi.moviecatalogue2.model.Movie;
import com.pradita.budi.moviecatalogue2.model.ResponseTv;
import com.pradita.budi.moviecatalogue2.model.TvShow;
import com.pradita.budi.moviecatalogue2.network.ConfigRetrofit;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.pradita.budi.moviecatalogue2.api.Constant.API_KEY;

public class SearchTvShowActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    TvShowAdapter adapter;
    private ArrayList<TvShow> tvShows;
    private final String language = "en-US";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_tv_show);

        recyclerView = findViewById(R.id.rv_tvshow_search);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        adapter = new TvShowAdapter(getApplicationContext(), tvShows);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);


        loadTvShow();

    }

    private void loadTvShow(){
        ConfigRetrofit.service.getAllTvShows(API_KEY, language)
                .enqueue(new Callback<ResponseTv>() {
                    @Override
                    public void onResponse(Call<ResponseTv> call, Response<ResponseTv> response) {
                        tvShows = (ArrayList<TvShow>) response.body().getResults();
                        recyclerView.setAdapter(new TvShowAdapter(getApplicationContext(), tvShows));
                        adapter.notifyDataSetChanged();
                        Log.d("status", "status" + response.body().getResults());

                    }

                    @Override
                    public void onFailure(Call<ResponseTv> call, Throwable t) {
                        Log.d("Error", t.getMessage());
                        Toast.makeText(getApplicationContext(), "Filed to get data", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menuTv) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.tvshow_menu, menuTv);

        SearchManager manager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        if (manager != null) {
            SearchView searchView = (SearchView) (menuTv.findItem(R.id.search_tv)).getActionView();
            searchView.setSearchableInfo(manager.getSearchableInfo(getComponentName()));
            searchView.setQueryHint(getResources().getString(R.string.search_hint_tvshow));
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    ConfigRetrofit.service.searchTvShow(API_KEY, language, query)
                            .enqueue(new Callback<ResponseTv>() {
                                @Override
                                public void onResponse(Call<ResponseTv> call, Response<ResponseTv> response) {
                                    tvShows = (ArrayList<TvShow>) response.body().getResults();
                                    recyclerView.setAdapter(new TvShowAdapter(getApplicationContext(), tvShows));
                                    adapter.notifyDataSetChanged();
                                    Log.d("status", "status" + response.body().getResults());
                                }

                                @Override
                                public void onFailure(Call<ResponseTv> call, Throwable t) {
                                    Log.d("Error", t.getMessage());
                                    Toast.makeText(getApplicationContext(), "Fieled to get Data", Toast.LENGTH_SHORT).show();
                                }
                            });
                    return true;
                }
                @Override
                public boolean onQueryTextChange(String newText) {
                    return false;
                }
            });
        }
        return super.onCreateOptionsMenu(menuTv);
    }
}
