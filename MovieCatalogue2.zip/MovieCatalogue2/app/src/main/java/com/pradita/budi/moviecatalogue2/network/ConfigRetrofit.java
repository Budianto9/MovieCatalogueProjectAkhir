package com.pradita.budi.moviecatalogue2.network;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import static com.pradita.budi.moviecatalogue2.api.Constant.BASE_URL;

public class ConfigRetrofit {
    public static Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build();

    public static Service service = retrofit.create(Service.class);
}
