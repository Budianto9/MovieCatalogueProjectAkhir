package com.pradita.budi.moviecatalogue2.model;

import android.database.Cursor;
import android.os.Parcel;
import android.os.Parcelable;

import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.RELEASE_DATE;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.OVERVIEW_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.POSTER_PATH_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TITLE_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TVSHOW_ID;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.getColumnInt;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.getColumnString;

public class TvShow implements Parcelable {

    private int id;
    private String name;
    private String overview;
    private String poster_path;

    public TvShow(){}


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }



    public String getPoster_path() {
        return poster_path;
    }

    public void setPoster_path(String poster_path) {
        this.poster_path = poster_path;
    }

    public TvShow(Cursor cursor){
        this.id = getColumnInt(cursor, TVSHOW_ID);
        this.name = getColumnString(cursor, TITLE_TVSHOW);
        this.overview = getColumnString(cursor, OVERVIEW_TVSHOW);
        this.poster_path = getColumnString(cursor, POSTER_PATH_TVSHOW);
    }

    protected TvShow(Parcel in) {
        id = in.readInt();
        name = in.readString();
        overview = in.readString();
        poster_path = in.readString();
    }

    public static final Creator<TvShow> CREATOR = new Creator<TvShow>() {
        @Override
        public TvShow createFromParcel(Parcel in) {
            return new TvShow(in);
        }

        @Override
        public TvShow[] newArray(int size) {
            return new TvShow[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(name);
        dest.writeString(overview);
        dest.writeString(poster_path);
    }
}
