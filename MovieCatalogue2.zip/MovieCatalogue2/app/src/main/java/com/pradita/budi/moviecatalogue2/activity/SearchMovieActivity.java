package com.pradita.budi.moviecatalogue2.activity;

import android.app.SearchManager;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.widget.Toast;

import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.adapter.RecyclerViewAdapter;
import com.pradita.budi.moviecatalogue2.model.Movie;
import com.pradita.budi.moviecatalogue2.model.Response;
import com.pradita.budi.moviecatalogue2.network.ConfigRetrofit;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;

import static com.pradita.budi.moviecatalogue2.api.Constant.API_KEY;

public class SearchMovieActivity extends AppCompatActivity {

    RecyclerViewAdapter adapter;
    RecyclerView recyclerView;
    private ArrayList<Movie> movies;
    private final String language = "en-US";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_movie);


        recyclerView = findViewById(R.id.rv_movie_search);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        adapter = new RecyclerViewAdapter(getApplicationContext(), movies);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        loadMovie();


    }

    private void loadMovie() {
        ConfigRetrofit.service.getAllMovies(API_KEY, language)
                .enqueue(new Callback<Response>() {
                    @Override
                    public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                        movies = (ArrayList<Movie>) response.body().getResults();
                        recyclerView.setAdapter(new RecyclerViewAdapter(getApplicationContext(), movies));
                        adapter.notifyDataSetChanged();
                        Log.d("status", "status" + response.body().getResults());
                    }

                    @Override
                    public void onFailure(Call<Response> call, Throwable t) {
                        Log.d("Error", t.getMessage());
                        Toast.makeText(getApplicationContext(), "Fieled to get Data", Toast.LENGTH_SHORT).show();
                    }
                });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu searchMenu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.movie_menu, searchMenu);

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        if (searchManager != null) {
            SearchView searchView = (SearchView) (searchMenu.findItem(R.id.search_movie)).getActionView();
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setQueryHint(getResources().getString(R.string.search_hint_movie));
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    ConfigRetrofit.service.searchMovie(API_KEY, language, query)
                            .enqueue(new Callback<Response>() {
                                @Override
                                public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                                    movies = (ArrayList<Movie>) response.body().getResults();
                                    recyclerView.setAdapter(new RecyclerViewAdapter(getApplicationContext(), movies));
                                    adapter.notifyDataSetChanged();
                                    Log.d("status", "status" + response.body().getResults());
                                }

                                @Override
                                public void onFailure(Call<Response> call, Throwable t) {
                                    Log.d("Error", t.getMessage());
                                    Toast.makeText(getApplicationContext(), "Fieled to get Data", Toast.LENGTH_SHORT).show();
                                }
                            });
                    return true;
                }
                @Override
                public boolean onQueryTextChange(String newText) {
                    return false;
                }
            });
        }
        return super.onCreateOptionsMenu(searchMenu);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}
