package com.pradita.budi.moviecatalogue2.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.activity.DetailActivity;
import com.pradita.budi.moviecatalogue2.api.Constant;
import com.pradita.budi.moviecatalogue2.model.ResultMovie;

import java.util.ArrayList;

public class SearchAdapter extends RecyclerView.Adapter<SearchAdapter.ViewHolder>{

    public Context context;
    public ArrayList<ResultMovie> list;


    public SearchAdapter(Context context, ArrayList<ResultMovie> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return  new ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull SearchAdapter.ViewHolder holder, int position) {
        final ResultMovie resultMovie = list.get(position);
        holder.getAdapterPosition();
        holder.title.setText(list.get(position).getTitle());
        holder.overview.setText(list.get(position).getOverview());
        holder.realease_date.setText(list.get(position).getReleaseDate());
        Glide.with(context)
                .load(Constant.IMAGE_URL + list.get(position).getPosterPath())
                .placeholder(R.drawable.load)
                .into(holder.img);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("id", resultMovie.getId());
                intent.putExtra("title", resultMovie.getTitle());
                intent.putExtra("overview", resultMovie.getOverview());
                intent.putExtra("release_date", resultMovie.getReleaseDate());
                intent.putExtra("poster_path", resultMovie.getPosterPath());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        if (list == null){
            return 0;
        }
        return list.size();
    }



    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView title, overview, realease_date;
        private ImageView img;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.title_detail_cv);
            overview = itemView.findViewById(R.id.overview_detail_cv);
            realease_date = itemView.findViewById(R.id.release_date_detail_cv);
            img = itemView.findViewById(R.id.iv_poster_cv);
        }
    }
}
