package com.pradita.budi.moviecatalogue2.activity;

import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.api.Constant;
import com.pradita.budi.moviecatalogue2.model.Movie;
import com.pradita.budi.moviecatalogue2.model.Response;
import com.pradita.budi.moviecatalogue2.network.ConfigRetrofit;
import com.pradita.budi.moviecatalogue2.scheduler.AlarmDailyReceiver;
import com.pradita.budi.moviecatalogue2.scheduler.AlarmReleaseReceiver;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;

public class SettingActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getFragmentManager().beginTransaction().replace(android.R.id.content, new MyPreferenceFragment()).commit();

    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }


    public static class MyPreferenceFragment extends PreferenceFragment implements Preference.OnPreferenceChangeListener {


        private ArrayList<Movie> listMovie;
        String language;
        String primary_release_date_gte = "primary_release_date.gte";
        String primary_release_date_lte = "primary_release_date.lte";
        AlarmDailyReceiver alarmDailyReceiver = new AlarmDailyReceiver();
        AlarmReleaseReceiver alarmReleaseReceiver = new AlarmReleaseReceiver();

        String dailyReminder, releaseTodayReminder, settingLocale;

        @Override
        public void onCreate(final Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.preferences);

            dailyReminder = getResources().getString(R.string.key_daily_reminder);
            releaseTodayReminder = getResources().getString(R.string.key_release_today_reminder);
            settingLocale = getResources().getString(R.string.key_setting_locale);

            findPreference(dailyReminder).setOnPreferenceChangeListener(this);
            findPreference(releaseTodayReminder).setOnPreferenceChangeListener(this);

        }

        @Override
        public boolean onPreferenceChange(Preference preference, Object object) {
            String key = preference.getKey();
            boolean isOn = (boolean) object;


            if (key.equals(dailyReminder)) {
                if (isOn) {
                    alarmDailyReceiver.setDailyReminderAlarm(getActivity());
                } else {
                    alarmDailyReceiver.cancelAlarm(getActivity());
                }
                Toast.makeText(getActivity(), getString(R.string.alarm_notif) + " " + (isOn ? getString(R.string.active) : getString(R.string.deactivated)), Toast.LENGTH_SHORT).show();
                return true;

            }
            if (key.equals(releaseTodayReminder)) {
                if (isOn) {
                    alarmReleaseReceiver.setReleaseReminderAlarm(getActivity());

                } else
                    alarmReleaseReceiver.cancelAlarm(getActivity());

                Toast.makeText(getActivity(), getString(R.string.alarm_upcoming) + " " + (isOn ? getString(R.string.active) : getString(R.string.deactivated)), Toast.LENGTH_SHORT).show();
                return true;
            }


            return false;
        }

    }
}