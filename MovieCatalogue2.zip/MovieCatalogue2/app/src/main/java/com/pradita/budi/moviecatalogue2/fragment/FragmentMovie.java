package com.pradita.budi.moviecatalogue2.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.adapter.RecyclerViewAdapter;
import com.pradita.budi.moviecatalogue2.model.Movie;
import com.pradita.budi.moviecatalogue2.network.TheMovieAPI;

import java.util.ArrayList;
import java.util.List;

import static com.pradita.budi.moviecatalogue2.api.Constant.API_KEY;
import static com.pradita.budi.moviecatalogue2.api.Constant.BASE_URL;

public class FragmentMovie extends Fragment {
    private RecyclerViewAdapter adapter;
    RecyclerView mRecyclerView;

    private ArrayList<Movie> movies;
    private final String Movie = BASE_URL + "discover/movie?api_key=" + API_KEY;


    public FragmentMovie() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.movie_fragment, container, false);
        mRecyclerView =  (RecyclerView) view.findViewById(R.id.movie_recyclerview);
        adapter = new RecyclerViewAdapter(getContext(), movies);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(adapter);

        if (savedInstanceState == null){
            mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
            movies = new ArrayList<>();
            adapter = new RecyclerViewAdapter(getContext(), movies);
            mRecyclerView.setAdapter(adapter);

        }else {

            movies = savedInstanceState.getParcelableArrayList("Movie");
            mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
            adapter.refill(movies);
        }

        fetchMoreItems();


        return view;
    }

    public void fetchMoreItems(){
        final ProgressDialog dialog =
                ProgressDialog.show(getContext(), "", "Loading", false);
        TheMovieAPI.fetchMovies(Movie + "&language=en-US", getContext(), new TheMovieAPI.MoviesAPICallBack() {
            @Override
            public void updateMoviesList(List<Movie> movies) {
                dialog.dismiss();
                adapter.setMoviesList(movies);
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelableArrayList("Movie", new ArrayList<>(movies));
    }


}
