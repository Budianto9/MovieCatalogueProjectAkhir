package com.pradita.budi.moviecatalogue2.api;

import com.pradita.budi.moviecatalogue2.BuildConfig;

public class Constant {
    public static String API_KEY = BuildConfig.API_KEY;

    public static String BASE_URL = "https://api.themoviedb.org/3/";

    public static String IMAGE_URL = "https://image.tmdb.org/t/p/w185/";

}
