package com.pradita.budi.moviecatalogue2.network;

import android.content.Context;
import android.widget.Toast;

import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.pradita.budi.moviecatalogue2.model.TvShow;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class TvShowAPI {
    public static void fetchData(String URL, final Context context, final TvShowAPICallBack callBack){
        JsonObjectRequest request = new JsonObjectRequest(URL,null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        if (response == null) {
                            Toast.makeText(context, "Gagal memanggil data item, mohon coba kembali.", Toast.LENGTH_LONG).show();
                            return;
                        }
                        try {
                            JSONArray jsonArray = response.getJSONArray("results");
                            List<TvShow> tvShowList = new Gson().fromJson(jsonArray.toString(), new TypeToken<List<TvShow>>() {}.getType());
                            callBack.updateTvShowList(tvShowList);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, "Gagal memanggil web service - "+error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        MyApplication.getInstance().addToRequestQueue(request);
    }


    public interface TvShowAPICallBack{
        void updateTvShowList(List<TvShow> tvShowList);
    }
}
