package com.pradita.budi.moviecatalogue2.adapter;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.activity.DetailActivity;
import com.pradita.budi.moviecatalogue2.api.Constant;
import com.pradita.budi.moviecatalogue2.model.Movie;


public class FavouriteAdapter extends RecyclerView.Adapter<FavouriteAdapter.ViewHolder> {


    private Cursor movieCursor;
    public Activity activity;

    public FavouriteAdapter(Activity activity) {
        this.activity = activity;
    }

    public void setListMovie(Cursor movieCursor) {
        this.movieCursor = movieCursor;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, final int position) {
        final Movie movie = getItem(position);
        holder.title.setText(movie.getTitle());
        holder.overview.setText(movie.getOverview());
        Glide.with(activity)
                .load(Constant.IMAGE_URL + movie.getPoster_path())
                .placeholder(R.drawable.load)
                .into(holder.imageView);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity, DetailActivity.class);
                intent.putExtra("id", movie.getId());
                intent.putExtra("title", movie.getTitle());
                intent.putExtra("overview", movie.getOverview());
                intent.putExtra("poster_path", movie.getPoster_path());
                activity.startActivity(intent);
            }
        });
    }

    private Movie getItem(int position){
        if (!movieCursor.moveToPosition(position)) {
            throw new IllegalStateException("Position invalid");
        }
        return new Movie(movieCursor);
    }

    @Override
    public int getItemCount() {
        if (movieCursor == null) return 0;
        return movieCursor.getCount();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView title, overview;
        private ImageView imageView;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.title_detail_cv);
            overview = itemView.findViewById(R.id.overview_detail_cv);
            imageView = itemView.findViewById(R.id.iv_poster_cv);
        }
    }
}
