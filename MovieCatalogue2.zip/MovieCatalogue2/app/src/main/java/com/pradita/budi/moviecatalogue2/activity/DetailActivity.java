package com.pradita.budi.moviecatalogue2.activity;

import android.content.ContentValues;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.database.MovieHelper;


import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.CONTENT_URI;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.MOVIE_ID;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.OVERVIEW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.POSTER_PATH;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.RELEASE_DATE;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.TITLE_MOVIE;

public class DetailActivity extends AppCompatActivity {


    FloatingActionButton fabFavourite;

    private TextView dtlTitle, dtlOverview;
    private ImageView imageView;

    private String title, overview, poster_path, release_date;
    private int id_movie;
    private Boolean isFavourite = false;
    MovieHelper movieHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        fabFavourite = findViewById(R.id.fabFavourite);

        imageView = findViewById(R.id.dtl_photo);
        dtlTitle = findViewById(R.id.dtl_name);
        dtlOverview = findViewById(R.id.dtl_overview);


        setData();
        backButton();
        loadData();

        fabFavourite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isFavourite){
                    movieHelper.open();
                    movieHelper.deleteProvider(String.valueOf(id_movie));
                    movieHelper.close();
                    fabFavourite.setImageResource(R.drawable.ic_favorite_border_black);
                    Toast.makeText(DetailActivity.this, title + " Sudah di hapus dari Favourite", Toast.LENGTH_SHORT).show();
                } else {
                    ContentValues cv = new ContentValues();
                    cv.put(MOVIE_ID, id_movie);
                    cv.put(TITLE_MOVIE, title);
                    cv.put(OVERVIEW, overview);
                    cv.put(RELEASE_DATE, release_date);
                    cv.put(POSTER_PATH, poster_path);
                    getContentResolver().insert(CONTENT_URI, cv);
                    fabFavourite.setImageResource(R.drawable.ic_favorite);
                    Toast.makeText(DetailActivity.this, title + " Berhasil di tambah ke Favourite", Toast.LENGTH_SHORT).show();
                    isFavourite = true;
                }

            }
        });

    }



    private void setData() {
        id_movie = getIntent().getIntExtra("id",0);
        title = getIntent().getStringExtra("title");
        overview = getIntent().getStringExtra("overview");
        release_date = getIntent().getStringExtra("release_date");
        poster_path = getIntent().getStringExtra("poster_path");



        final String poster = "https://image.tmdb.org/t/p/w500" + poster_path;
        Glide.with(this)
                .load(poster)
                .placeholder(R.drawable.load)
                .into(imageView);

        dtlTitle.setText(title);
        dtlOverview.setText(overview);
    }


    private void backButton() {
        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle(getIntent().getStringExtra("title"));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void loadData() {
        movieHelper = new MovieHelper(this);
        movieHelper.open();
        isFavourite = movieHelper.getMoviebyId(String.valueOf(id_movie));
        movieHelper.close();
    }

}
