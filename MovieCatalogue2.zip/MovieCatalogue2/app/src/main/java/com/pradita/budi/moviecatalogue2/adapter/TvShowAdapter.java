package com.pradita.budi.moviecatalogue2.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.activity.DetailTvActivity;
import com.pradita.budi.moviecatalogue2.api.Constant;
import com.pradita.budi.moviecatalogue2.model.TvShow;

import java.util.ArrayList;
import java.util.List;

public class TvShowAdapter extends RecyclerView.Adapter<TvShowAdapter.ViewHolder> {

    public Context context;
    private ArrayList<TvShow> tvShows;


    public TvShowAdapter(Context context, ArrayList<TvShow> tvShows){
        this.tvShows = tvShows;
        this.context = context;
    }
    public void refill(ArrayList<TvShow> tvShows) {
        this.tvShows = new ArrayList<>();
        this.tvShows.addAll(tvShows);

        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public TvShowAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new TvShowAdapter.ViewHolder(LayoutInflater.from(context).inflate(R.layout.list_tv_item, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull final TvShowAdapter.ViewHolder holder, final int position) {
        final TvShow tvShow = tvShows.get(position);
        holder.getAdapterPosition();
        holder.tv_name.setText(tvShows.get(position).getName());
        holder.tv_overview.setText(tvShows.get(position).getOverview());
        Glide.with(context)
                .load(Constant.IMAGE_URL + tvShows.get(position).getPoster_path())
                .placeholder(R.drawable.load)
                .into(holder.tv_img);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Context context = v.getContext();
                Intent intent = new Intent(context, DetailTvActivity.class);
                intent.putExtra("id", tvShow.getId());
                intent.putExtra("name", tvShow.getName());
                intent.putExtra("overview", tvShow.getOverview());
                intent.putExtra("poster_path", tvShow.getPoster_path());
                context.startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        if (tvShows == null){
            return 0;
        }
        return tvShows.size();
    }

    public void setTvShowList(List<TvShow> tvShowList){
        tvShows.addAll(tvShowList);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tv_name, tv_overview;
        private ImageView tv_img;

        ViewHolder(View itemView) {
            super(itemView);

            tv_name = itemView.findViewById(R.id.title_detail_tv);
            tv_overview = itemView.findViewById(R.id.overview_detail_tv);
            tv_img = itemView.findViewById(R.id.iv_poster_tv);
        }
    }
}
