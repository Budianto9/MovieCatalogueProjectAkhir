package com.pradita.budi.moviecatalogue2.fragment;


import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.adapter.FavouriteAdapter;

import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.CONTENT_URI;

/**
 * A simple {@link Fragment} subclass.
 */
public class MovieFavFragment extends Fragment {

    RecyclerView recyclerView;

    private Cursor cursor;

    private FavouriteAdapter favouriteAdapter;

    public MovieFavFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_movie_fav, container, false);
        recyclerView = view.findViewById(R.id.favmovie_recyclerview);
        favouriteAdapter = new FavouriteAdapter(getActivity());
        favouriteAdapter.notifyDataSetChanged();
        favouriteAdapter.setListMovie(cursor);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(favouriteAdapter);
        new loadMovieAsyncTask().execute();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        new loadMovieAsyncTask().execute();
    }

    @SuppressLint("StaticFieldLeak")
    private class loadMovieAsyncTask extends AsyncTask<Void, Void, Cursor>{

        @Override
        protected Cursor doInBackground(Void... voids) {
            return getActivity().getContentResolver().query(
                    CONTENT_URI,
                    null,
                    null,
                    null,
                    null
            );
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            super.onPostExecute(cursor);

            cursor = cursor;
            favouriteAdapter.setListMovie(cursor);
            favouriteAdapter.notifyDataSetChanged();
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }
}
