package com.pradita.budi.moviecatalogue2.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;

import com.pradita.budi.moviecatalogue2.database.TvHelper;


import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.AUTHORITY;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.CONTENT_URI_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TABLE_TVSHOW;

public class TvProvider extends ContentProvider {

    private static final int TV = 1;
    private static final int TV_ID = 2;

    private static final UriMatcher sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static {

        sUriMatcher.addURI(AUTHORITY, TABLE_TVSHOW, TV);

        sUriMatcher.addURI(AUTHORITY, TABLE_TVSHOW + "/#", TV_ID);
    }

    private TvHelper tvHelper;

    @Override
    public boolean onCreate() {
        tvHelper = new TvHelper(getContext());
        tvHelper.open();
        return true;
    }

    @Override
    public Cursor query(@NonNull Uri uri, String[] projection, String selection, String[] selectionArgs, String sortOrder) {
        Cursor cursor;
        int i = sUriMatcher.match(uri);
        if (i == TV) {
            cursor = tvHelper.queryProvider();
        } else if (i == TV_ID) {
            cursor = tvHelper.queryByIdProvider(uri.getLastPathSegment());
        } else {
            cursor = null;
        }
        if (cursor != null) {
            cursor.setNotificationUri(getContext().getContentResolver(), uri);
        }
        return cursor;
    }

    @Override
    public String getType(@NonNull Uri uri) {
        return null;
    }

    @Override
    public Uri insert(@NonNull Uri uri, ContentValues contentValues) {
        long added;

        if (sUriMatcher.match(uri) == TV) {
            added = tvHelper.insertProvider(contentValues);
        } else {
            added = 0;
        }
        if (added > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return Uri.parse(CONTENT_URI_TVSHOW + "/" + added);
    }

    @Override
    public int update(@NonNull Uri uri, ContentValues contentValues, String selection, String[] selectionArgs) {
        int updated;
        if (sUriMatcher.match(uri) == TV_ID) {
            updated = tvHelper.updateProvider(uri.getLastPathSegment(), contentValues);
        } else {
            updated = 0;
        }

        if (updated > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return updated;
    }


    @Override
    public int delete(@NonNull Uri uri, String selectiton, String[] selectionArgs) {
        int deleted;
        if (sUriMatcher.match(uri) == TV_ID) {
            deleted = tvHelper.deleteProvider(uri.getLastPathSegment());
        } else {
            deleted = 0;
        }
        if (deleted > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return deleted;
    }
}
