package com.pradita.budi.moviecatalogue2.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.MOVIE_ID;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.OVERVIEW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.POSTER_PATH;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.RELEASE_DATE;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.TABLE_MOVIE;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.TITLE_MOVIE;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.OVERVIEW_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.POSTER_PATH_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TABLE_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TITLE_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TVSHOW_ID;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static String DATABASE_NAME = "moviedb";

    private static final int DATABASE_VERSION = 1;

    private static final String SQL_CREATE_TABLE_MOVIE = "CREATE TABLE " + TABLE_MOVIE +
            "(" + MOVIE_ID + " integer primary key," +
            TITLE_MOVIE + " text not null, " +
            RELEASE_DATE+ " text not null, " +
            OVERVIEW + " text not null, " +
            POSTER_PATH + " text not null);";

    private static final String SQL_CREATE_TABLE_TVSHOW = "CREATE TABLE " + TABLE_TVSHOW +
            "(" + TVSHOW_ID + " integer primary key," +
            TITLE_TVSHOW + " text not null, " +
            OVERVIEW_TVSHOW + " text not null, " +
            POSTER_PATH_TVSHOW + " text not null);";

    DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_TABLE_MOVIE);
        db.execSQL(SQL_CREATE_TABLE_TVSHOW);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_MOVIE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_TVSHOW);
        onCreate(db);
    }
}