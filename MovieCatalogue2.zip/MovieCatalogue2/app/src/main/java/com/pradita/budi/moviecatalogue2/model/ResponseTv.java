package com.pradita.budi.moviecatalogue2.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ResponseTv {

    @SerializedName("results")
    private List<TvShow> results;

    public List<TvShow> getResults() {
        return results;
    }

    public void setResultTv(List<TvShow> results) {
        this.results = results;
    }

    @Override
    public String toString(){
        return
                "Response{" +
                        ",results = '" + results + '\'' +
                        "}";
    }
}
