package com.pradita.budi.moviecatalogue2.scheduler;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.widget.Toast;

import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.activity.DetailActivity;
import com.pradita.budi.moviecatalogue2.api.Constant;
import com.pradita.budi.moviecatalogue2.model.Movie;
import com.pradita.budi.moviecatalogue2.model.Response;
import com.pradita.budi.moviecatalogue2.network.ConfigRetrofit;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;

public class AlarmReleaseReceiver extends BroadcastReceiver {

    public static final String NOTIFICATION_CHANNEL_ID = "10001";
    public ArrayList<Movie> listMovie;
    private static int notifId = 1000;
    Context context;
    String primary_release_date_gte = "primary_release_date.gte";
    String primary_release_date_lte = "primary_release_date.lte";

    @Override
    public void onReceive(Context context, Intent intent) {
        getMovieRelease();
    }

    private void showNotification(Context context, int notifId, String title) {
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(
                Context.NOTIFICATION_SERVICE);
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        Intent intent = new Intent(context, DetailActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, notifId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT);


        Uri alarmRingtone = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context)
                .setSmallIcon(R.drawable.ic_alarm_black_24dp)
                .setContentTitle(title)
                .setContentText(String.valueOf(String.format(context.getString(R.string.todayrelease), title)))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setColor(ContextCompat.getColor(context, android.R.color.transparent))
                .setVibrate(new long[]{1000, 1000, 1000, 1000, 1000})
                .setSound(alarmRingtone);


        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, "NOTIFICATION_CHANNEL_NAME", importance);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.enableVibration(true);
            notificationChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});

            builder.setChannelId(NOTIFICATION_CHANNEL_ID);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(notificationChannel);
            }
        }

        if (notificationManager != null) {
            notificationManager.notify(notifId, builder.build());
        }
    }

    public void setReleaseReminderAlarm(Context context) {

        int delay = 0;
            cancelAlarm(context);
            AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(context, AlarmReleaseReceiver.class);
            intent.putExtra("id", notifId);

            PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 100, intent, PendingIntent.FLAG_UPDATE_CURRENT);

            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, 8);
            calendar.set(Calendar.MINUTE, 0);
            calendar.set(Calendar.SECOND, 0);

            int SDK_INT = Build.VERSION.SDK_INT;
            if (SDK_INT < Build.VERSION_CODES.KITKAT) {
                if (alarmManager != null) {
                    alarmManager.set(AlarmManager.RTC_WAKEUP,
                            calendar.getTimeInMillis() + delay, pendingIntent);
                }
            } else if (SDK_INT > Build.VERSION_CODES.KITKAT && SDK_INT < Build.VERSION_CODES.M) {
                if (alarmManager != null) {
                    alarmManager.setInexactRepeating(
                            AlarmManager.RTC_WAKEUP,
                            calendar.getTimeInMillis() + delay,
                            AlarmManager.INTERVAL_DAY,
                            pendingIntent
                    );
                }
            } else if (SDK_INT >= Build.VERSION_CODES.M) {
                if (alarmManager != null) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                            calendar.getTimeInMillis() + delay, pendingIntent);
                }
            }

            notifId += 1;


    }

    public void cancelAlarm(Context context) {

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.cancel(getPendingIntent(context));

    }

    private PendingIntent getPendingIntent(Context context) {
        Intent intent = new Intent(context, AlarmDailyReceiver.class);

        return PendingIntent.getBroadcast(context, notifId, intent,
                PendingIntent.FLAG_CANCEL_CURRENT);
    }

    private void getMovieRelease() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date date = new Date();
        final String now = dateFormat.format(date);


        ConfigRetrofit.service.getReleaseToday(Constant.API_KEY, primary_release_date_gte, primary_release_date_lte)
                .enqueue(new Callback<Response>() {
                    @Override
                    public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                        listMovie = (ArrayList<Movie>) response.body().getResults();
                        for (Movie movie : listMovie) {
                            if (movie.getRelease_date().equals(now)) {
                                listMovie.add(movie);
                                Log.d("onSuccess", "" + listMovie.size());
                                showNotification(context, movie.getId(), movie.getTitle());
                            }
                        }
                    }


                    @Override
                    public void onFailure(Call<Response> call, Throwable t) {
                        Toast.makeText(context, "EROR"
                                , Toast.LENGTH_SHORT).show();
                        Log.d(" Error", t.getMessage());
                    }
                });
    }

}

