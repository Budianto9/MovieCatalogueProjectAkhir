package com.pradita.budi.moviecatalogue2.network;

import com.pradita.budi.moviecatalogue2.model.Response;
import com.pradita.budi.moviecatalogue2.model.ResponseTv;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface Service {
    @GET("/3/discover/movie")
    Call<Response> getAllMovies(@Query("api_key") String api_key,
                                @Query("language") String language);

    @GET("/3/search/movie")
    Call<Response> searchMovie(@Query("api_key") String api_key,
                               @Query("language") String language,
                               @Query("query") String query);

    @GET("/3/discover/tv")
    Call<ResponseTv> getAllTvShows(@Query("api_key") String api_key,
                                   @Query("language") String language);

    @GET("/3/search/tv")
    Call<ResponseTv> searchTvShow(@Query("api_key") String api_key,
                                @Query("language") String language,
                                @Query("query") String query);

    @GET("/3/movie/upcoming")
    Call<Response> getReleaseToday(@Query("api_key") String api_key,
                                   @Query("primary_release_date.gte") String primary_release_date_gte,
                                   @Query("primary_release_date.lte") String primary_release_date_lte);
}
