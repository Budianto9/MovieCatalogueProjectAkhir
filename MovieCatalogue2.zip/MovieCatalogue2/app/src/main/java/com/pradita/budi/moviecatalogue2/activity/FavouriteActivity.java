package com.pradita.budi.moviecatalogue2.activity;

import android.content.Intent;
import android.provider.Settings;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.adapter.ViewPagerAdapter;
import com.pradita.budi.moviecatalogue2.fragment.FragmentMovie;
import com.pradita.budi.moviecatalogue2.fragment.FragmentTv;
import com.pradita.budi.moviecatalogue2.fragment.MovieFavFragment;
import com.pradita.budi.moviecatalogue2.fragment.TvFavFragment;

public class FavouriteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);

        TabLayout tabLayout = findViewById(R.id.tablayout_fav);
        ViewPager viewPager = findViewById(R.id.viewpager_fav);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());

        adapter.AddFragment(new MovieFavFragment(), getString(R.string.Movie));
        adapter.AddFragment(new TvFavFragment(), getString(R.string.TvShow));

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_movie);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_tv);


        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.language:
                Intent changeLanguage = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(changeLanguage);
                break;

            case R.id.favourite:
                Intent listMain = new Intent(this, MainActivity.class);
                startActivity(listMain);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
