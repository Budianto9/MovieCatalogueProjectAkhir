package com.pradita.budi.moviecatalogue2.fragment;


import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.adapter.FavouriteTvAdapter;

import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.CONTENT_URI_TVSHOW;

/**
 * A simple {@link Fragment} subclass.
 */
public class TvFavFragment extends Fragment {

    RecyclerView recyclerView;
    private Cursor cursor;

    private FavouriteTvAdapter favouriteTvAdapter;

    public TvFavFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_tv_fav, container, false);
        recyclerView = view.findViewById(R.id.favtvshow_recyclerview);
        favouriteTvAdapter = new FavouriteTvAdapter(getActivity());
        favouriteTvAdapter.notifyDataSetChanged();
        favouriteTvAdapter.setListTv(cursor);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(favouriteTvAdapter);
        new TvFavFragment.loadTvShowAsyncTask().execute();
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        new loadTvShowAsyncTask().execute();
    }

    @SuppressLint("StaticFieldLeak")
    private class loadTvShowAsyncTask extends AsyncTask<Void, Void, Cursor> {

        @Override
        protected Cursor doInBackground(Void... voids) {
            return getActivity().getContentResolver().query(
                    CONTENT_URI_TVSHOW,
                    null,
                    null,
                    null,
                    null
            );
        }

        @Override
        protected void onPostExecute(Cursor cursor) {
            super.onPostExecute(cursor);

            cursor = cursor;
            favouriteTvAdapter.setListTv(cursor);
            favouriteTvAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();

    }
}
