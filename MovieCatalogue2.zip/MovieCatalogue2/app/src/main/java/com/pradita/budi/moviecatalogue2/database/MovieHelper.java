package com.pradita.budi.moviecatalogue2.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.pradita.budi.moviecatalogue2.model.Movie;

import java.util.ArrayList;

import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.MOVIE_ID;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.OVERVIEW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.POSTER_PATH;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.RELEASE_DATE;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.TABLE_MOVIE;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.MovieColumns.TITLE_MOVIE;

public class MovieHelper {
    private static String DATABASE_TABLE = TABLE_MOVIE;
    private Context context;
    private DatabaseHelper databaseHelper;

    private SQLiteDatabase database;

    public MovieHelper(Context context){
        this.context = context;
    }

    public MovieHelper open() throws SQLException {
        databaseHelper = new DatabaseHelper(context);
        database = databaseHelper.getWritableDatabase();
        return this;
    }

    public void close(){
        databaseHelper.close();
    }

    public ArrayList<Movie> query() {
        ArrayList<Movie> arrayList = new ArrayList<>();
        Cursor cursor = database.query(DATABASE_TABLE,
                null,
                null,
                null,
                null,
                null, MOVIE_ID + " DESC",
                null);
        cursor.moveToFirst();
        Movie movieList;
        if (cursor.getCount() > 0){
            do {
                movieList = new Movie();
                movieList.setId(cursor.getInt(cursor.getColumnIndexOrThrow(MOVIE_ID)));
                movieList.setTitle(cursor.getString(cursor.getColumnIndexOrThrow(TITLE_MOVIE)));
                movieList.setOverview(cursor.getString(cursor.getColumnIndexOrThrow(OVERVIEW)));
                movieList.setRelease_date(cursor.getString(cursor.getColumnIndexOrThrow(RELEASE_DATE)));
                movieList.setPoster_path(cursor.getString(cursor.getColumnIndexOrThrow(POSTER_PATH)));
                cursor.moveToNext();
            } while (!cursor.isAfterLast());
        }
        cursor.close();
        return arrayList;
    }


    public boolean getMoviebyId(String id) {
        boolean result = false;
        Cursor cursor = database.query(DATABASE_TABLE,
                null,
                MOVIE_ID + " = '"+id+"'",
                null,
                null,
                null,
                MOVIE_ID + " ASC",
                null);
        cursor.moveToFirst();
        ArrayList<Movie> arrayList = new ArrayList<>();
        Movie movieitem;
        if (cursor.getCount() > 0) {
            result = true;
        }
        cursor.close();
        return result;
    }

    public Cursor queryByIdProvider(String id) {
        return database.query(DATABASE_TABLE, null
                , MOVIE_ID + "=?"
                , new String[]{id}
                , null
                , null
                , null
                , null);
    }

    public Cursor queryProvider() {
        return database.query(DATABASE_TABLE
                , null
                , null
                , null
                , null
                , null
                , MOVIE_ID + " DESC");
    }

    public long insertProvider(ContentValues values) {
        return database.insert(DATABASE_TABLE, null, values);
    }


    public int updateProvider(String id,ContentValues values){
        return database.update(DATABASE_TABLE,values,MOVIE_ID +" = ?",new String[]{id} );
    }

    public int deleteProvider(String id){
        return database.delete(DATABASE_TABLE,MOVIE_ID + " = ?", new String[]{id});
    }
}
