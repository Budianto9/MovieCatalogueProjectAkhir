package com.pradita.budi.moviecatalogue2.activity;

import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.adapter.RecyclerViewAdapter;
import com.pradita.budi.moviecatalogue2.adapter.SearchAdapter;
import com.pradita.budi.moviecatalogue2.adapter.ViewPagerAdapter;
import com.pradita.budi.moviecatalogue2.api.Constant;
import com.pradita.budi.moviecatalogue2.fragment.FragmentMovie;
import com.pradita.budi.moviecatalogue2.fragment.FragmentTv;
import com.pradita.budi.moviecatalogue2.model.Movie;
import com.pradita.budi.moviecatalogue2.model.Response;
import com.pradita.budi.moviecatalogue2.model.ResultMovie;
import com.pradita.budi.moviecatalogue2.network.ConfigRetrofit;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Callback;

public class MainActivity extends AppCompatActivity {

    RecyclerViewAdapter adapter;
    List<Movie> mainList;
    RecyclerView recyclerView;
    Context context;
    private final String language = "en-US";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TabLayout tabLayout = findViewById(R.id.tablayout_id);
        ViewPager viewPager = findViewById(R.id.viewpager_id);
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());

        adapter.AddFragment(new FragmentMovie(), getString(R.string.Movie));
        adapter.AddFragment(new FragmentTv(), getString(R.string.TvShow));

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);

        tabLayout.getTabAt(0).setIcon(R.drawable.ic_movie);
        tabLayout.getTabAt(1).setIcon(R.drawable.ic_tv);


        ActionBar actionBar = getSupportActionBar();
        actionBar.setElevation(0);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.language:
                Intent changeLanguage = new Intent(Settings.ACTION_LOCALE_SETTINGS);
                startActivity(changeLanguage);
                break;

            case R.id.favourite:
                Intent favList = new Intent(this, FavouriteActivity.class);
                startActivity(favList);
                break;

            case R.id.id_search_movie:
                Intent searchMovie = new Intent(this, SearchMovieActivity.class);
                startActivity(searchMovie);
                break;

            case R.id.id_search_tv:
                Intent searchTv = new Intent(this, SearchTvShowActivity.class);
                startActivity(searchTv);
                break;

            case R.id.setting:
                Intent setting = new Intent(this, SettingActivity.class);
                startActivity(setting);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

}
