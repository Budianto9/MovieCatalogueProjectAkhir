package com.pradita.budi.moviecatalogue2.database;

import android.database.Cursor;
import android.net.Uri;
import android.provider.BaseColumns;

public final class DatabaseContract {

    public static final String AUTHORITY = "com.pradita.budi.moviecatalogue2";
    private static final String SCHEME = "content";


    private DatabaseContract(){}

    public static class MovieColumns implements BaseColumns{


        public static final String TABLE_MOVIE = "movie";
        public static final String MOVIE_ID = MovieColumns._ID;
        public static final String TITLE_MOVIE = "title";
        public static final String OVERVIEW = "overview";
        public static final String RELEASE_DATE = "release_date";
        public static final String POSTER_PATH = "poster_path";

        public static final Uri CONTENT_URI = new Uri.Builder().scheme(SCHEME)
                .authority(AUTHORITY)
                .appendPath(TABLE_MOVIE)
                .build();
        }

        public static final class TvShowColumns implements BaseColumns{

            public static final String TABLE_TVSHOW = "tvshow";
            public static final String TVSHOW_ID = TvShowColumns._ID;
            public static final String TITLE_TVSHOW = "name";
            public static final String OVERVIEW_TVSHOW = "overview";
            public static final String POSTER_PATH_TVSHOW = "poster_path";

            public static final Uri CONTENT_URI_TVSHOW = new Uri.Builder().scheme(SCHEME)
                    .authority(AUTHORITY)
                    .appendPath(TABLE_TVSHOW)
                    .build();
        }



        public static String getColumnString(Cursor cursor, String columnName){
            return cursor.getString(cursor.getColumnIndex(columnName));
        }


        public static int getColumnInt(Cursor cursor, String columnName){
            return cursor.getInt(cursor.getColumnIndex(columnName));
        }

        public static long getColumnLong(Cursor cursor, String columnName){
            return cursor.getLong(cursor.getColumnIndex(columnName));
        }
}
