package com.pradita.budi.moviecatalogue2.activity;

import android.content.ContentValues;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.pradita.budi.moviecatalogue2.R;
import com.pradita.budi.moviecatalogue2.database.TvHelper;

import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.CONTENT_URI_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.OVERVIEW_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.POSTER_PATH_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TITLE_TVSHOW;
import static com.pradita.budi.moviecatalogue2.database.DatabaseContract.TvShowColumns.TVSHOW_ID;

public class DetailTvActivity extends AppCompatActivity {

    private String name, overview_tv, poster_path_tv;
    private int id_tv;

    FloatingActionButton fabFavouriteTv;
    private ImageView ivPoster;
    private TextView tvTitle, tvOverview;

    private Boolean isFavourite = false;
    TvHelper tvHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tv);

        ivPoster = findViewById(R.id.dtl_photo_tv);
        tvTitle = findViewById(R.id.dtl_name_tv);
        tvOverview = findViewById(R.id.dtl_overview_tv);

        fabFavouriteTv = findViewById(R.id.fabFavouriteTv);


        setData();
        backButton();
        loadData();


        fabFavouriteTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isFavourite){
                    tvHelper.open();
                    tvHelper.deleteProvider(String.valueOf(id_tv));
                    tvHelper.close();
                    fabFavouriteTv.setImageResource(R.drawable.ic_favorite_border_black);
                    Toast.makeText(DetailTvActivity.this, name + " Sudah di hapus dari Favourite", Toast.LENGTH_SHORT).show();
                } else {
                    ContentValues cv = new ContentValues();
                    cv.put(TVSHOW_ID, id_tv);
                    cv.put(TITLE_TVSHOW, name);
                    cv.put(OVERVIEW_TVSHOW, overview_tv);
                    cv.put(POSTER_PATH_TVSHOW, poster_path_tv);
                    getContentResolver().insert(CONTENT_URI_TVSHOW, cv);
                    fabFavouriteTv.setImageResource(R.drawable.ic_favorite);
                    Toast.makeText(DetailTvActivity.this, name + " Berhasil di tambah ke Favourite", Toast.LENGTH_SHORT).show();
                    isFavourite = true;
                }

            }
        });
    }


    private void setData(){
        id_tv = getIntent().getIntExtra("id",1);
        name = getIntent().getStringExtra("name");
        overview_tv = getIntent().getStringExtra("overview");
        poster_path_tv = getIntent().getStringExtra("poster_path");


        final String poster = "https://image.tmdb.org/t/p/w500" + poster_path_tv;
        Glide.with(this)
                .load(poster)
                .placeholder(R.drawable.load)
                .into(ivPoster);

        tvTitle.setText(name);
        tvOverview.setText(overview_tv);
    }

    private void backButton(){
        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle(getIntent().getStringExtra("title"));
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    private void loadData() {
        tvHelper = new TvHelper(this);
        tvHelper.open();
        isFavourite = tvHelper.getTvShowbyId(String.valueOf(id_tv));
        tvHelper.close();
    }
}
